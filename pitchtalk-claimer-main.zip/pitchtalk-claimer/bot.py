import sys
import base64
import time

sys.dont_write_bytecode = True

from smart_airdrop_claimer import base
from core.token import get_token
from core.info import get_info
from core.task import process_do_task, process_claim_ref
from core.upgrade import process_upgrade_character, process_upgrade_speed
from core.farm import process_farming

# Custom banner function with corrected Base64 decoding
def display_banner():
    banner_encoded = """
    4paR4paA4paA4paI4paR4paI4paA4paI4paR4paA4paI4paA4paR4paI4paA4paICuKWkeKWhOKW
    gOKWkeKWkeKWiOKWgOKWiOKWkeKWkeKWiOKWkeKWkeKWiOKWkeKWiArilpHiloDiloDiloDilpHi
    loDilpHiloDilpHiloDiloDiloDilpHiloDilpHiloAK4pWU4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
    4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ
    4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWQ4pWXCuKVkSAgICAgICAgICAgICAgICAgICAgICAgICAg
    ICAgICAgICDilZEK4pWRICBaQUlOIEFSQUlOICAgICAgICAgICAgICAgICAgICAgIOKVkQrilZEg
    IEFVVE8gU0NSSVBUIE1BU1RFUiAgICAgICAgICAgICAg4pWRCuKVkSAgICAgICAgICAgICAgICAg
    ICAgICAgICAgICAgICDilZEK4pWRICBKT0lOIFRFTEVHUkFNIENIQU5ORUwgTk9XISAgICAgIOKV
    kQrilZEgIGh0dHBzOi8vdC5tZS9BaXJkcm9wU2NyaXB0NiAgICAgICAgICAgICAg4pWRCuKVkSAg
    QEFpcmRyb3BTY3JpcHQ2IC0gT0ZGSUNJQUwgICAgICDilZEK4pWRICBDSEFOTkVMICAgICAgICAg
    ICAgICAgICAgICAgICAgIOKVkQrilZEgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDi
    lZEK4pWRICBGT0NSQSBDSVNZQ09NQVMgLSAgICAgICAgICAgICAg4pWRCuKVkSAgIEVDT05PTU9T
    LSBQUk9NRVRITkUgICDilZEK4pWRICBDSEFOTkVMICAgICAgICAgICAgICAgICAgICAgICAgICDi
    lZEK4pWRICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pWRCuKVkSAgRkFTVCAtIFJF
    TElBQkxFIC0gU0VDVVJFICAgICAgICDilZEK4pWRICBTQ1JJUFRTIEVYUEVSVCAgICAgICAgICAg
    IOZC4pWTCuKVkSAgICAK
    """
    # Decode and print banner, ignoring any invalid bytes
    banner_decoded = base64.b64decode(banner_encoded).decode('utf-8', errors='ignore')
    print(banner_decoded)

class PitchTalk:
    def __init__(self):
        # Get file paths
        self.data_file = base.file_path(file_name="data.txt")
        self.config_file = base.file_path(file_name="config.json")

        # Initialize line
        self.line = base.create_line(length=50)

        # Load config
        self.auto_do_task = base.get_config(
            config_file=self.config_file, config_name="auto-do-task"
        )
        self.auto_claim_ref = base.get_config(
            config_file=self.config_file, config_name="auto-claim-ref"
        )
        self.auto_upgrade_character = base.get_config(
            config_file=self.config_file, config_name="auto-upgrade-character"
        )
        self.auto_upgrade_speed = base.get_config(
            config_file=self.config_file, config_name="auto-upgrade-speed"
        )
        self.auto_farm = base.get_config(
            config_file=self.config_file, config_name="auto-farm"
        )

    def main(self):
        while True:
            base.clear_terminal()
            display_banner()  # Display only the custom Base64 banner

            # Rest of the main loop code
            data = open(self.data_file, "r").read().splitlines()
            num_acc = len(data)
            base.log(self.line)
            base.log(f"{base.green}Number of accounts: {base.white}{num_acc}")

            for no, data in enumerate(data):
                base.log(self.line)
                base.log(f"{base.green}Account number: {base.white}{no+1}/{num_acc}")

                try:
                    token = get_token(data=data)

                    if token:
                        get_info(data=data, token=token)

                        # Auto tasks
                        if self.auto_do_task:
                            base.log(f"{base.yellow}Auto Do Task: {base.green}ON")
                            process_do_task(data=data, token=token)
                        else:
                            base.log(f"{base.yellow}Auto Do Task: {base.red}OFF")

                        if self.auto_claim_ref:
                            base.log(f"{base.yellow}Auto Claim Ref: {base.green}ON")
                            process_claim_ref(data=data, token=token)
                        else:
                            base.log(f"{base.yellow}Auto Claim Ref: {base.red}OFF")

                        if self.auto_upgrade_character:
                            base.log(f"{base.yellow}Auto Upgrade Character: {base.green}ON")
                            process_upgrade_character(data=data, token=token)
                        else:
                            base.log(f"{base.yellow}Auto Upgrade Character: {base.red}OFF")

                        if self.auto_upgrade_speed:
                            base.log(f"{base.yellow}Auto Upgrade Speed: {base.green}ON")
                            process_upgrade_speed(data=data, token=token)
                        else:
                            base.log(f"{base.yellow}Auto Upgrade Speed: {base.red}OFF")

                        if self.auto_farm:
                            base.log(f"{base.yellow}Auto Farm: {base.green}ON")
                            process_farming(data=data, token=token)
                        else:
                            base.log(f"{base.yellow}Auto Farm: {base.red}OFF")

                        get_info(data=data, token=token)

                    else:
                        base.log(f"{base.red}Token not found! Please get new query id")
                except Exception as e:
                    base.log(f"{base.red}Error: {base.white}{e}")

            print()
            wait_time = 60 * 60
            base.log(f"{base.yellow}Wait for {int(wait_time/60)} minutes!")
            time.sleep(wait_time)


if __name__ == "__main__":
    try:
        pitchtalk = PitchTalk()
        pitchtalk.main()
    except KeyboardInterrupt:
        sys.exit()